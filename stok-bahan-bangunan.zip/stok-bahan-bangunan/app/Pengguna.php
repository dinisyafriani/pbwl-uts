<?php
namespace App;

class Pengguna extends DB{
    
    public function __construct(){
        parent::__construct();
    }

    public function index(){
        $sql = "select * from users";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();

        $data = [];
        while ($rows = $stmt->fetch()){
            $data[] = $rows;    
        }

        return $data;
    }   

    public function insert(){
        $name = $_POST['name'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $sql = "INSERT INTO users VALUES ('', '$name', '$email', '$password')";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
    }

    public function edit($id){
        $sql = "SELECT * FROM users WHERE id='$id'";
        $stmt = $this->db->prepare($sql);

        $stmt->execute();
        $row = $stmt->fetch();

        return $row;
    }   

    public function update($id){
        $name = $_POST['name'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $sql = "UPDATE users SET name = '$name', email = '$email', password = '$password' WHERE id='$id'";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
    }

    public function delete(){
        $id = $_POST['id'];
        $sql = "DELETE FROM users WHERE id='$id'";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
    }

}