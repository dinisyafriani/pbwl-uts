<?php
namespace App;

class BarangKeluar extends DB{
    
    public function __construct(){
        parent::__construct();
    }

    public function index(){
        $sql = "SELECT * from barang_keluars";
        $stmt = $this->db->prepare($sql);
        
        $stmt->execute();
        
        $data = [];
        while ($rows = $stmt->fetch()){
            $data[] = $rows;    
        }
    
        return $data;
    } 
    
    public function getBarangMasuk($id){
        $sql = "SELECT * FROM barang_masuks WHERE id='$id'";
        $stmt = $this->db->prepare($sql);

        $stmt->execute();
        $row = $stmt->fetch();

        return $this->getBarang($row['barang_id']);
    }
    
    public function getBarang($id){
        $sql = "SELECT * FROM barangs WHERE id='$id'";
        $stmt = $this->db->prepare($sql);

        $stmt->execute();
        $row = $stmt->fetch();

        return $row;
    }

    public function insert(){
        $barang_masuk_id = $_POST['barang_masuk_id'];
        $tgl_keluar = $_POST['tgl_keluar'];
        $jumlah = $_POST['jumlah'];
        
        $barang_masuk = "SELECT * FROM barang_masuks WHERE id='$barang_masuk_id'";
        $stmt_barang_masuk = $this->db->prepare($barang_masuk);

        $stmt_barang_masuk->execute();
        $data_barang_masuk = $stmt_barang_masuk->fetch();
        
        $jumlah_barang_masuk = (int)$data_barang_masuk['jumlah'] - $jumlah;
        
        $update_jumlah = "UPDATE barang_masuks SET jumlah = '$jumlah_barang_masuk' WHERE id='$barang_masuk_id'";
        $stmt_update_jumlah = $this->db->prepare($update_jumlah);
        $stmt_update_jumlah->execute();
        
        $sql = "INSERT INTO barang_keluars VALUES ('', '$barang_masuk_id', '$tgl_keluar', '$jumlah')";
        $stmt = $this->db->prepare($sql);
     
        $stmt->execute();        
    }

    public function edit($id){
        $sql = "SELECT * FROM barang_keluars WHERE id='$id'";
        $stmt = $this->db->prepare($sql);
        
        $stmt->execute();
        $row = $stmt->fetch();

        return $row;
    }

    public function update($id){
        $barang_masuk_id = $_POST['barang_masuk_id'];
        $tgl_keluar = $_POST['tgl_keluar'];
        $jumlah = $_POST['jumlah'];

        $sql = "UPDATE barang_keluars SET tgl_keluar = '$tgl_keluar', barang_masuk_id = '$barang_masuk_id', 
                jumlah = '$jumlah' WHERE id='$id'";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
    }

    public function delete(){
        $id = $_POST['id'];
        $sql = "DELETE FROM barang_keluars WHERE id='$id'";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
    }

}