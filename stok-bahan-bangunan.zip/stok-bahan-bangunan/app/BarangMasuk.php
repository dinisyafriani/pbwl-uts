<?php
namespace App;

class BarangMasuk extends DB{
    
    public function __construct(){
        parent::__construct();
    }

    public function index(){
        $sql = "SELECT * from barang_masuks";
        $stmt = $this->db->prepare($sql);
        
        $stmt->execute();
        
        $data = [];
        while ($rows = $stmt->fetch()){
            $data[] = $rows;    
        }
    
        return $data;
    } 
    
    public function getBarang($id){
        $sql = "SELECT * FROM barangs WHERE id='$id'";
        $stmt = $this->db->prepare($sql);

        $stmt->execute();
        $row = $stmt->fetch();

        return $row;
    } 

    public function insert(){
        $barang_id = $_POST['barang_id'];
        $tgl_masuk = $_POST['tgl_masuk'];
        $jumlah = $_POST['jumlah'];
        
        $sql = "INSERT INTO barang_masuks VALUES ('', '$barang_id', '$tgl_masuk', '$jumlah')";
        $stmt = $this->db->prepare($sql);
     
        $stmt->execute();
    }

    public function edit($id){
        $sql = "SELECT * FROM barang_masuks WHERE id='$id'";
        $stmt = $this->db->prepare($sql);
        
        $stmt->execute();
        $row = $stmt->fetch();

        return $row;
    }

    public function update($id){
        $barang_id = $_POST['barang_id'];
        $tgl_masuk = $_POST['tgl_masuk'];
        $jumlah = $_POST['jumlah'];

        $sql = "UPDATE barang_masuks SET tgl_masuk = '$tgl_masuk', barang_id = '$barang_id', 
                jumlah = '$jumlah' WHERE id='$id'";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
    }

    public function delete(){
        $id = $_POST['id'];
        $sql = "DELETE FROM barang_masuks WHERE id='$id'";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
    }

}