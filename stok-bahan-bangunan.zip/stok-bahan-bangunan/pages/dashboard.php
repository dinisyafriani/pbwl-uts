<div class="container" style="padding-top: 40px">
    <div class="card">
        <h1>Selamat Datang di App Manajemen Stok Bahan Bangunan</h1>
    </div>
</div>