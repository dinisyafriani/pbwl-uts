<?php
    require_once "config.php";
    $barang_masuk = new App\BarangMasuk();
    $data_barang_masuk = $barang_masuk->index();

    $barang_keluar = new App\BarangKeluar();
    $row = $barang_keluar->edit($_GET['id']);

    if (isset($_POST['simpan'])) {
        $barang_keluar->update($_GET['id']);
        header("location:index.php?page=barang_keluar");
    }
?>

<div class="container" style="padding-top: 40px">
    <div class="card" style="width: 600px">
        <div class="card-title">Data Barang Keluar</div>
        <form method="POST">
            <div class="form-group">
                <label for="">Barang</label>
                <select name="barang_id" id="">
                    <option value="">-Silahkan Pilih-</option>
                    <?php foreach($data_barang as $item) { ?>
                    <option value="<?php echo $item['id'] ?>"
                        <?php if ($item['id'] == $row['barang_id']) { ?>
                            selected
                        <?php } ?>
                    >
                        <?php echo $item['nama'] ?>
                    </option>
                    <?php } ?>
                </select>
            </div>

            <div class="form-group">
                <label for="">Tanggal Masuk</label>
                <input type="date" name="tgl_masuk" value="<?php echo $row['tgl_masuk'] ?>">
            </div>

            <div class="form-group">
                <label for="">Jumlah</label>
                <input type="number" name="jumlah" value="<?php echo $row['jumlah'] ?>">
            </div>
            <button class="btn btn-success" name="simpan">Simpan</button>
        </form>
    </div>
</div>