<?php
    require_once "config.php";

    $barang_keluar = new App\BarangKeluar();
    $rows = $barang_keluar->index();

    if (isset($_POST['hapus'])) {
        $barang_keluar->delete();
        header("location:index.php?page=index_barang_keluar");
    }
?>

<div class="container" style="padding-top: 40px">
    <div class="card">
        <div class="card-title">Data Barang Keluar</div>
        <a href="index.php?page=tambah_barang_keluar">
            <button class="btn btn-success">Tambah</button>
        </a>
        <p></p>
        <table>
            <tr>
                <th>Nama</th>
                <th>Tgl Keluar</th>
                <th>Jumlah</th>
                <th>Aksi</th>
            </tr>
            <?php foreach ($rows as $row) { ?>
            <?php
                $barang = $barang_keluar->getBarangMasuk($row['barang_masuk_id']);    
            ?>
            <tr>
                <td><?php echo $barang['nama'] ?></td>
                <td><?php echo date('d-m-Y', strtotime($row['tgl_keluar'])) ?></td>
                <td><?php echo $row['jumlah'] ?></td>
                <td style="width: 25%">
                <a href="index.php?page=edit_barang_keluar&id=<?php echo $row['id']?>">
                    <button class="btn btn-warning">Edit</button>
                </a>
                <form method="POST" style="display: inline">
                    <input type="text" name="id" value="<?php echo $row['id'] ?>" style="display:none">
                    <button class="btn btn-danger" name="hapus">Hapus</button>
                </form>
                </td>
            </tr>
            <?php } ?>
        </table>
    </div>
</div>